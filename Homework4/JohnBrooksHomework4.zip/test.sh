echo export OMP_NUM_THREADS=16
export OMP_NUM_THREADS=16
./fast_mmf.out
echo export OMP_NUM_THREADS=12
export OMP_NUM_THREADS=12
./fast_mmf.out
echo export OMP_NUM_THREADS=10
export OMP_NUM_THREADS=10
./fast_mmf.out
echo export OMP_NUM_THREADS=8
export OMP_NUM_THREADS=8
./fast_mmf.out
echo export OMP_NUM_THREADS=6
export OMP_NUM_THREADS=6
./fast_mmf.out
echo export OMP_NUM_THREADS=4
export OMP_NUM_THREADS=4
./fast_mmf.out
echo export OMP_NUM_THREADS=3
export OMP_NUM_THREADS=3
./fast_mmf.out
echo export OMP_NUM_THREADS=2
export OMP_NUM_THREADS=2
./fast_mmf.out
echo export OMP_NUM_THREADS=1
export OMP_NUM_THREADS=1
./fast_mmf.out

